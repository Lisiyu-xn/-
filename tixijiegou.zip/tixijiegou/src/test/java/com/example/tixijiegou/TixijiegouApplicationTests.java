package com.example.tixijiegou;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
public class ServiceTest {

	@Autowired
	private BusinessService businessService;

	@Autowired
	private ShopService shopService;

	@Autowired
	private ItemService itemService;

	@Autowired
	private CustomerService customerService;

	@Autowired
	private OrderService orderService;

	@Test
	public void testBusinessService() {
		// 测试创建商家
		Business newBusiness = new Business("Example Business");
		Business createdBusiness = businessService.createBusiness(newBusiness);
		assertNotNull(createdBusiness.getId());

		// 测试获取商家列表
		int initialBusinessCount = businessService.getAllBusinesses().size();
		assertEquals(initialBusinessCount, 1);

		// 测试获取商家详情
		Business retrievedBusiness = businessService.getBusinessById(createdBusiness.getId());
		assertNotNull(retrievedBusiness);

		// 测试更新商家信息
		retrievedBusiness.setName("Updated Business Name");
		Business updatedBusiness = businessService.updateBusiness(retrievedBusiness.getId(), retrievedBusiness);
		assertEquals(updatedBusiness.getName(), "Updated Business Name");

		// 测试删除商家
		businessService.deleteBusiness(updatedBusiness.getId());
		int finalBusinessCount = businessService.getAllBusinesses().size();
		assertEquals(finalBusinessCount, 0);
	}

}

