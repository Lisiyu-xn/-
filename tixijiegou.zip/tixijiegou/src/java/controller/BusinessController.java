import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/businesses")
public class BusinessController {

    @Autowired
    private BusinessService businessService;

    // 获取所有商家
    @GetMapping
    public List<Business> getAllBusinesses() {
        return businessService.getAllBusinesses();
    }

    // 根据ID获取商家
    @GetMapping("/{id}")
    public Business getBusinessById(@PathVariable Long id) {
        return businessService.getBusinessById(id);
    }

    // 创建新商家
    @PostMapping
    public Business createBusiness(@RequestBody Business business) {
        return businessService.createBusiness(business);
    }

    // 更新商家信息
    @PutMapping("/{id}")
    public Business updateBusiness(@PathVariable Long id, @RequestBody Business business) {
        return businessService.updateBusiness(id, business);
    }

    // 删除商家
    @DeleteMapping("/{id}")
    public void deleteBusiness(@PathVariable Long id) {
        businessService.deleteBusiness(id);
    }

    // 获取商家的所有门店
    @GetMapping("/{id}/shops")
    public List<Shop> getBusinessShops(@PathVariable Long id) {
        return businessService.getBusinessShops(id);
    }

    // 在商家下创建新门店
    @PostMapping("/{id}/shops")
    public Shop createShopForBusiness(@PathVariable Long id, @RequestBody Shop shop) {
        return businessService.createShopForBusiness(id, shop);
    }

    // 在商家下上架商品
    @PostMapping("/{id}/shops/{shopId}/items")
    public Item shelveItemForBusiness(@PathVariable Long id, @PathVariable Long shopId, @RequestBody Item item) {
        return businessService.shelveItemForBusiness(id, shopId, item);
    }

    // 获取商家的所有订单
    @GetMapping("/{id}/orders")
    public List<Order> getBusinessOrders(@PathVariable Long id) {
        return businessService.getBusinessOrders(id);
    }

    // 确认商家的订单
    @PostMapping("/{id}/orders/{orderId}/confirm")
    public Order confirmOrderForBusiness(@PathVariable Long id, @PathVariable Long orderId) {
        return businessService.confirmOrderForBusiness(id, orderId);
    }

    // 取消商家的订单
    @PostMapping("/{id}/orders/{orderId}/cancel")
    public Order cancelOrderForBusiness(@PathVariable Long id, @PathVariable Long orderId) {
        return businessService.cancelOrderForBusiness(id, orderId);
    }
}
