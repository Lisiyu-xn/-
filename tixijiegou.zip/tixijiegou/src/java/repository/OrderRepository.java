import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    // 根据订单编号查询订单
    Order findByOrderNumber(String orderNumber);

    // 根据客户ID查询订单列表
    List<Order> findByCustomerId(Long customerId);

    // 可以根据具体需求添加其他自定义查询方法
}
