import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ShopRepository extends JpaRepository<Shop, Long> {
    // 根据门店名称查询门店
    Shop findByName(String name);

    // 根据商家ID查询该商家的所有门店列表
    List<Shop> findByBusinessId(Long businessId);

}
