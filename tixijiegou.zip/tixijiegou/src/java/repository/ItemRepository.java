import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
    // 根据商品名称查询商品
    Item findByName(String name);

    // 根据商品类别查询商品列表
    List<Item> findByCategory(String category);

    // 可以根据具体需求添加其他自定义查询方法
}
