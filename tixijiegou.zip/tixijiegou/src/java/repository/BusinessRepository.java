import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BusinessRepository extends JpaRepository<Business, Long> {
    Business findByName(String name);

    // 根据商家类型查询商家列表
    List<Business> findByType(String type);

}
