import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // 根据客户姓名查询客户
    Customer findByName(String name);

    // 根据客户年龄查询客户列表
    List<Customer> findByAge(int age);

    // 可以根据具体需求添加其他自定义查询方法
}
