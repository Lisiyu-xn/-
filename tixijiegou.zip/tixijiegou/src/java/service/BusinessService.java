import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BusinessService {

    @Autowired
    private BusinessRepository businessRepository;

    // 获取所有商家
    public List<Business> getAllBusinesses() {
        return businessRepository.findAll();
    }

    // 根据ID获取商家
    public Business getBusinessById(Long id) {
        return businessRepository.findById(id).orElse(null);
    }
    // 创建新商家
    public Business createBusiness(Business business) {
        return businessRepository.save(business);
    }
    // 更新商家信息
    public Business updateBusiness(Long id, Business updatedBusiness) {
        Business existingBusiness = businessRepository.findById(id).orElse(null);
        if (existingBusiness != null) {
            // 更新商家信息
            existingBusiness.setName(updatedBusiness.getName());
            existingBusiness.setAddress(updatedBusiness.getAddress());
            // 其他更新操作...

            // 保存更新后的商家信息
            return businessRepository.save(existingBusiness);
        }
        return null;
    }

    // 删除商家
    public void deleteBusiness(Long id) {
        businessRepository.deleteById(id);
    }
}
