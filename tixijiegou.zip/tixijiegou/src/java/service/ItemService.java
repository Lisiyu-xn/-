import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    // 获取所有商品
    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    // 根据ID获取商品
    public Item getItemById(Long id) {
        return itemRepository.findById(id).orElse(null);
    }

    // 创建新商品
    public Item createItem(Item item) {
        return itemRepository.save(item);
    }

    // 更新商品信息
    public Item updateItem(Long id, Item updatedItem) {
        Item existingItem = itemRepository.findById(id).orElse(null);
        if (existingItem != null) {
            // 更新商品信息


            // 保存更新后的商品信息
            return itemRepository.save(existingItem);
        }
        return null;
    }

    // 删除商品
    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }
}
