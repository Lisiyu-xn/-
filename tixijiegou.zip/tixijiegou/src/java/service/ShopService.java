import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShopService {

    @Autowired
    private ShopRepository shopRepository;

    // 获取所有商店
    public List<Shop> getAllShops() {
        return shopRepository.findAll();
    }

    // 根据ID获取商店
    public Shop getShopById(Long id) {
        return shopRepository.findById(id).orElse(null);
    }

    // 创建新商店
    public Shop createShop(Shop shop) {
        return shopRepository.save(shop);
    }

    // 更新商店信息
    public Shop updateShop(Long id, Shop updatedShop) {
        Shop existingShop = shopRepository.findById(id).orElse(null);
        if (existingShop != null) {
            // 更新商店信息

            // 保存更新后的商店信息
            return shopRepository.save(existingShop);
        }
        return null;
    }

    // 删除商店
    public void deleteShop(Long id) {
        shopRepository.deleteById(id);
    }
}
