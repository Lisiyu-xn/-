import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    // 获取所有订单
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // 根据ID获取订单
    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }

    // 创建新订单
    public Order createOrder(Order order) {
        return orderRepository.save(order);
    }

    // 更新订单信息
    public Order updateOrder(Long id, Order updatedOrder) {
        Order existingOrder = orderRepository.findById(id).orElse(null);
        if (existingOrder != null) {
            // 更新订单信息


            // 保存更新后的订单信息
            return orderRepository.save(existingOrder);
        }
        return null;
    }

    // 删除订单
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}

