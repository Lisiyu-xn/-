import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // 获取所有客户
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    // 根据ID获取客户
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    // 创建新客户
    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    // 更新客户信息
    public Customer updateCustomer(Long id, Customer updatedCustomer) {
        Customer existingCustomer = customerRepository.findById(id).orElse(null);
        if (existingCustomer != null) {
            // 更新客户信息
            existingCustomer.setName(updatedCustomer.getName());
            existingCustomer.setEmail(updatedCustomer.getEmail());


            // 保存更新后的客户信息
            return customerRepository.save(existingCustomer);
        }
        return null;
    }

    // 删除客户
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}

