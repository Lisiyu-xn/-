import javax.persistence.*;

// 命令接口 OrderCommand
public interface OrderCommand {
    void execute();
}

// 具体的命令类 AddItemCommand
class AddItemCommand implements OrderCommand {
    private LineItem lineItem;

    public AddItemCommand(LineItem lineItem) {
        this.lineItem = lineItem;
    }

    @Override
    public void execute() {
        // 具体业务逻辑 - 将商品加入订单
        lineItem.getOrder().addLineItem(lineItem);
    }
}

// 具体的命令类 RemoveItemCommand
class RemoveItemCommand implements OrderCommand {
    private LineItem lineItem;

    public RemoveItemCommand(LineItem lineItem) {
        this.lineItem = lineItem;
    }

    @Override
    public void execute() {
        // 具体业务逻辑 - 将商品从订单中移除
        lineItem.getOrder().removeLineItem(lineItem);
    }
}

// 实体类 LineItem
@Entity
public class LineItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int quantity;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne
    @JoinColumn(name = "item_id")
    private Item item;

    private OrderCommand addCommand;
    private OrderCommand removeCommand;

    // 构造函数注入命令
    public LineItem(OrderCommand addCommand, OrderCommand removeCommand) {
        this.addCommand = addCommand;
        this.removeCommand = removeCommand;
    }

    // 具体业务方法示例，调用命令对象执行具体操作
    public void addItemToOrder() {
        addCommand.execute();
    }

    public void removeItemFromOrder() {
        removeCommand.execute();
    }

    // 具体业务方法示例
    public double calculateSubtotal() {
        // 根据数量和商品单价计算小计
        return quantity * item.getPrice();
    }
}

