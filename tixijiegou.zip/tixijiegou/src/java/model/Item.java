import javax.persistence.*;

// 策略接口 SaleStrategy
interface SaleStrategy {
    boolean isOnSale(Item item);
    void putOnSale(Item item);
    void removeFromSale(Item item);
}

// 具体的策略类 OnSaleStrategy
class OnSaleStrategy implements SaleStrategy {
    @Override
    public boolean isOnSale(Item item) {
        // 根据业务逻辑判断商品是否上架
        return true;
    }

    @Override
    public void putOnSale(Item item) {
        // 将商品上架的业务逻辑
        System.out.println("Putting item on sale: " + item.getName());
    }

    @Override
    public void removeFromSale(Item item) {
        // 将商品下架的业务逻辑
        System.out.println("Removing item from sale: " + item.getName());
    }
}

// 具体的策略类 NotOnSaleStrategy
class NotOnSaleStrategy implements SaleStrategy {
    @Override
    public boolean isOnSale(Item item) {
        // 根据业务逻辑判断商品是否下架
        return false;
    }

    @Override
    public void putOnSale(Item item) {
        // 将商品上架的业务逻辑
        System.out.println("Putting item on sale: " + item.getName());
    }

    @Override
    public void removeFromSale(Item item) {
        // 将商品下架的业务逻辑
        System.out.println("Removing item from sale: " + item.getName());
    }
}

// 实体类 Item
@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne
    @JoinColumn(name = "shop_id")
    private Shop shop;

    private SaleStrategy saleStrategy;

    // 构造函数注入策略
    public Item(SaleStrategy saleStrategy) {
        this.saleStrategy = saleStrategy;
    }


    // 具体业务方法示例，委托给策略对象
    public boolean isOnSale() {
        return saleStrategy.isOnSale(this);
    }

    public void putOnSale() {
        saleStrategy.putOnSale(this);
    }

    public void removeFromSale() {
        saleStrategy.removeFromSale(this);
    }
}


