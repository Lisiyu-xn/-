import javax.persistence.*;
import java.util.List;

// 实体类 Business
@Entity
public class Business {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    // 其他属性
    @OneToMany(mappedBy = "business")
    private List<Shop> shops;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Shop> getShops() {
        return shops;
    }

    public void setShops(List<Shop> shops) {
        this.shops = shops;
    }
}
@Entity
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    // 其他属性
    @ManyToOne
    @JoinColumn(name = "business_id")
    private Business business;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Business getBusiness() {
        return business;
    }

    public void setBusiness(Business business) {
        this.business = business;
    }
}

// 工厂接口 BusinessFactory
public interface BusinessFactory {
    Business createBusiness(String name);
}

// 具体的工厂类 BusinessFactoryImpl
public class BusinessFactoryImpl implements BusinessFactory {
    @Override
    public Business createBusiness(String name) {
        Business business = new Business();
        business.setName(name);
        // 可以进行其他初始化操作
        return business;
    }
}

// 使用工厂模式的类 SomeClass
public class SomeClass {
    private BusinessFactory businessFactory;

    public SomeClass(BusinessFactory businessFactory) {
        this.businessFactory = businessFactory;
    }

    public void createBusinessAndAddToShop(String businessName, List<Shop> shops) {
        Business business = businessFactory.createBusiness(businessName);
        // 可以进行其他业务逻辑操作
        for (Shop shop : shops) {
            shop.setBusiness(business);
        }
    }
}

