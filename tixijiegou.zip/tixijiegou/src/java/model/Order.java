import javax.persistence.*;
import java.util.List;

@Entity
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String status;

    // 其他属性

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToMany(mappedBy = "order")
    private List<LineItem> lineItems;

    // 其他关联和属性的getter和setter方法
    // 省略构造方法和其他业务逻辑

    // getter和setter方法

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // 其他getter和setter方法

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<LineItem> getLineItems() {
        return lineItems;
    }

    public void setLineItems(List<LineItem> lineItems) {
        this.lineItems = lineItems;
    }

    // 具体业务方法示例

    public double calculateTotal() {
        // 计算订单总金额
        double total = 0.0;
        for (LineItem lineItem : lineItems) {
            total += lineItem.calculateSubtotal();
        }
        return total;
    }

}
