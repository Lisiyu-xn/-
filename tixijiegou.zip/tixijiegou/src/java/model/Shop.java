import javax.persistence.*;
import java.util.List;

// 责任链节点接口 ShopHandler
public interface ShopHandler {
    void handle(Shop shop, ShopItem shopItem);
}

// 具体的责任链节点类 AddShopItemHandler
class AddShopItemHandler implements ShopHandler {
    private ShopHandler nextHandler;

    public AddShopItemHandler(ShopHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handle(Shop shop, ShopItem shopItem) {
        // 具体业务逻辑 - 将商品添加到门店
        shop.addShopItem(shopItem);

        // 继续传递请求给下一个处理器
        if (nextHandler != null) {
            nextHandler.handle(shop, shopItem);
        }
    }
}

// 具体的责任链节点类 RemoveShopItemHandler
class RemoveShopItemHandler implements ShopHandler {
    private ShopHandler nextHandler;

    public RemoveShopItemHandler(ShopHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handle(Shop shop, ShopItem shopItem) {
        // 具体业务逻辑 - 从门店移除商品
        shop.removeShopItem(shopItem);

        // 继续传递请求给下一个处理器
        if (nextHandler != null) {
            nextHandler.handle(shop, shopItem);
        }
    }
}

// 实体类 Shop
@Entity
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    // 其他属性和注解

    @ManyToOne
    @JoinColumn(name = "business_id")
    private Business business;

    @OneToMany(mappedBy = "shop")
    private List<ShopItem> shopItems;

    @OneToMany(mappedBy = "shop")
    private List<Item> items;

    private ShopHandler addHandler;
    private ShopHandler removeHandler;

    // 构造函数注入责任链节点
    public Shop(ShopHandler addHandler, ShopHandler removeHandler) {
        this.addHandler = addHandler;
        this.removeHandler = removeHandler;
    }

    // 具体业务方法示例，调用责任链节点处理具体操作
    public void addShopItem(ShopItem shopItem) {
        addHandler.handle(this, shopItem);
    }

    public void removeShopItem(ShopItem shopItem) {
        removeHandler.handle(this, shopItem);
    }

    // 具体业务方法示例
    public void addShopItem(ShopItem shopItem) {
        // 添加商品到门店的业务逻辑
        this.shopItems.add(shopItem);
        shopItem.setShop(this);
    }

    public void removeShopItem(ShopItem shopItem) {
        // 从门店移除商品的业务逻辑
        this.shopItems.remove(shopItem);
        shopItem.setShop(null);
    }


}
