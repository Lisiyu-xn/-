import javax.persistence.*;
import java.util.List;
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "customer")
    private List<Order> orders;
    // 其他关联和属性的getter和setter方法
    // 构造方法
    public Customer() {
        // 默认构造方法
    }
    public Customer(String name) {
        this.name = name;
        // 其他属性的初始化
    }
    // getter和setter方法
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    // 其他getter和setter方法
    public List<Order> getOrders() {
        return orders;
    }
    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
    // 业务逻辑
    public void placeOrder(Order order) {
        if (orders == null) {
            orders = new ArrayList<>();
        }
        orders.add(order);
        order.setCustomer(this);
    }
    public void cancelOrder(Order order) {
        if (orders != null) {
            orders.remove(order);
            order.setCustomer(null);
        }
    }
}
